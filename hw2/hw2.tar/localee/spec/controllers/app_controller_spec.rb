require 'spec_helper'

describe AppController do

end
