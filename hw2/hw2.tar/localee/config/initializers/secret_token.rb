# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cs186p2::Application.config.secret_token = '5c71406a77480ef9fbb28a98a6a4bbeb4763fbc0931e9015b6f9b1bbec1866297220eef6acb2e592a30c5e8ebc5a2f27dbb7bbbc96e0f950ea12a5238d83d39e'
